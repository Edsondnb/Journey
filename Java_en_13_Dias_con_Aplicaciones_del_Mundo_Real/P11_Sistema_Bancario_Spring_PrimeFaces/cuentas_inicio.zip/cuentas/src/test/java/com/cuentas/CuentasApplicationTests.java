package com.cuentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
